from torch.utils.data import Dataset, DataLoader

import torch
from torch import nn
from torchvision.models import resnet18, ResNet18_Weights
from torchvision import transforms
from PIL import Image
import os
from torch.nn import CrossEntropyLoss, MSELoss
from torch.utils.data import random_split
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix
import numpy as np
import seaborn as sns


# from block import *


class RoughIQACNN(nn.Module):
    def __init__(self, num_layers, channels):  # 层数，通道数
        super(RoughIQACNN, self).__init__()
        layers = [
            nn.Sequential(
                nn.Conv2d(3 if i == 0 else channels[i - 1], channels[i], kernel_size=3, padding=1),  # 卷积
                nn.ReLU(),  # 激活函数
                nn.MaxPool2d(2)  # 最大池化
            ) for i in range(num_layers)
        ]
        # 'num_layers': 3,
        # 'channels': [16, 32, 64]
        layers.append(nn.AdaptiveAvgPool2d((1, 1)))  # 平均池化
        layers.append(nn.Flatten()) #降维
        layers.append(nn.Linear(channels[-1], 1))  # 线性

        self.model = nn.Sequential(*layers)

    def forward(self, x):
        return self.model(x)


class ObjectiveIQAFNN(nn.Module):
    def __init__(self, input_features, num_units, num_layers):
        super(ObjectiveIQAFNN, self).__init__()
        layers = []
        for i in range(num_layers):
            in_features = input_features if i == 0 else num_units
            layers.append(nn.Linear(in_features, num_units))
            layers.append(nn.ReLU())
        # 'input_features': 17,
        # 'num_units': 100,
        # 'num_layers': lso
        layers.append(nn.Linear(num_units, 1))
        self.model = nn.Sequential(*layers)

    def forward(self, x):
        return self.model(x)


class DynamicFC(nn.Module):
    def __init__(self, input_features, num_layers, num_units=100, ):
        super(DynamicFC, self).__init__()
        layers = []
        for i in range(num_layers):
            in_features = input_features if i == 0 else num_units
            layers.append(nn.Linear(in_features, num_units))
            layers.append(nn.ReLU())
        # 'input_features': 3,  # 根据前面层的输出调整
        # 'num_units': 100,
        # 'num_layers': lsf
        layers.append(nn.Linear(num_units, 1))
        self.model = nn.Sequential(*layers)

    def forward(self, x):
        return self.model(x)


class ResNetFeatureExtractor(nn.Module):
    def __init__(self, pretrained=True):
        super(ResNetFeatureExtractor, self).__init__()
        # 加载预训练的 ResNet18
        if pretrained:
            self.resnet = resnet18(weights=ResNet18_Weights.IMAGENET1K_V1)
        else:
            self.resnet = resnet18(pretrained=False)

        # 移除最后的全连接层
        self.features = nn.Sequential(*list(self.resnet.children())[:-1])
        self.fc = nn.Linear(512, 25)  # 假设我们想要进一步缩减特征
        self.fc2 = nn.Linear(25, 1)  # 语义iqa权重

    def forward(self, x):
        semantic_features = self.features(x)
        semantic_features = semantic_features.view(x.size(0), -1)  # 展平特征
        semantic_features = self.fc(semantic_features)  # 可选的新全连接层
        semantic_iqa = self.fc2(semantic_features)
        return semantic_iqa, semantic_features


class IQANet(nn.Module):
    def __init__(self, rough_iqa_config, objective_iqa_config, final_fc_config, *args, **kwargs):
        # 语义信息提取
        super().__init__(*args, **kwargs)
        self.semantic_extractor = ResNetFeatureExtractor(pretrained=True)

        # 粗略 IQA CNN
        self.rough_iqa_cnn = RoughIQACNN(**rough_iqa_config)

        # 客观 IQA FNN
        self.objective_iqa_fnn = ObjectiveIQAFNN(**objective_iqa_config)

        # 最终汇总
        self.final_fc = DynamicFC(**final_fc_config)

    def forward(self, x, distortion_scores):
        res_res = self.semantic_extractor(x)
        semantic_features = res_res[1]
        semantic_iqa = res_res[0]
        rough_iqa = self.rough_iqa_cnn(x)
        objective_iqa = self.objective_iqa_fnn(distortion_scores)

        combined_features = torch.cat([semantic_iqa, rough_iqa, objective_iqa], dim=1)
        iqa = self.final_fc(combined_features)

        ##
        # semantic_features = self.features(x)
        # semantic_features = semantic_features.view(x.size(0), -1)  # 展平特征
        # semantic_features = self.fc(semantic_features)  # 可选的新全连接层
        # semantic_iqa = self.fc2(semantic_features)  # 可选的新全连接层
        # # semantic_iqa= semantic_iqa.view(-1)
        #
        # # semantic_features = self.semantic_extractor(x)
        # rough_iqa = self.rough_iqa_cnn(x)
        # # rough_iqa = rough_iqa.view(-1)
        # objective_iqa = self.objective_iqa_fnn(distortion_scores)
        # objective_iqa = objective_iqa.view(-1, 1)
        # combined_features = torch.cat([semantic_iqa, rough_iqa, objective_iqa], dim=1)
        # iqa = self.final_fc(combined_features)

        return semantic_features, iqa

        # return output
