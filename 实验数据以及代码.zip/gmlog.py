import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.models as models
import cv2
import numpy as np
import os
import torch
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms



# 定义 GM-LOG 指标计算函数
def compute_gm_log(image):
    # 计算图像的梯度幅度
    sobelx = cv2.Sobel(image, cv2.CV_64F, 1, 0, ksize=3)
    sobely = cv2.Sobel(image, cv2.CV_64F, 0, 1, ksize=3)
    gradient_magnitude = np.sqrt(sobelx ** 2 + sobely ** 2)

    # 计算高斯拉普拉斯算子响应
    gaussian_blur = cv2.GaussianBlur(image, (5, 5), 0)
    laplacian = cv2.Laplacian(gaussian_blur, cv2.CV_64F)

    # 计算 GM-LOG 指标
    gm_log = np.mean(gradient_magnitude) * np.mean(np.abs(laplacian))

    return gm_log


# 定义混合模型
class HybridModel(nn.Module):
    def __init__(self):
        super(HybridModel, self).__init__()
        self.resnet_branch = models.resnet50(pretrained=True)
        self.conv_branch = nn.Sequential(
            nn.Conv2d(in_channels=3, out_channels=32, kernel_size=3, stride=1, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.fc_iqa = nn.Linear(1000 + 32, 1)  # 将 ResNet 和卷积分支的输出合并后再进行全连接

    def forward(self, x):
        resnet_output = self.resnet_branch(x)
        conv_output = self.conv_branch(x)

        # 将 ResNet 和卷积分支的输出进行展平
        resnet_output = resnet_output.view(resnet_output.size(0), -1)
        conv_output = conv_output.view(conv_output.size(0), -1)

        # 将 ResNet 和卷积分支的输出合并
        combined_output = torch.cat((resnet_output, conv_output), dim=1)

        # 使用全连接层输出最终的 IQA 指标
        iqa_score = self.fc_iqa(combined_output)
        return iqa_score


# 创建模型实例
model = HybridModel()


# 定义 TID2008 数据集类
class TID2008Dataset(Dataset):
    def __init__(self, root_dir, transform=None):
        self.root_dir = root_dir
        self.transform = transform
        self.image_files = sorted(os.listdir(root_dir))
        self.labels = []  # 如果有标签的话需要加载对应的标签数据

    def __len__(self):
        return len(self.image_files)

    def __getitem__(self, idx):
        image_path = os.path.join(self.root_dir, self.image_files[idx])
        image = cv2.imread(image_path)  # 读取图像
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)  # 转换颜色通道顺序

        if self.transform:
            image = self.transform(image)

        label = self.labels[idx]  # 获取对应的标签
        return image, label


# 数据集根目录
root_dir = "path/to/tid2008_dataset"

# 定义图像预处理和转换
transform = transforms.Compose([
    transforms.Resize((224, 224)),  # 调整图像大小
    transforms.ToTensor(),  # 转换为张量
    transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))  # 归一化
])

# 创建 TID2008 数据集实例
tid2008_dataset = TID2008Dataset(root_dir, transform=transform)

# 创建数据加载器
train_loader = DataLoader(tid2008_dataset, batch_size=4, shuffle=True)

# 创建模型实例
model = HybridModel()

# 定义损失函数和优化器
criterion = nn.MSELoss()
optimizer = torch.optim.Adam(model.parameters(), lr=0.001)

# 创建数据加载器
train_loader = DataLoader(dataset, batch_size=4, shuffle=True)

# 模型训练
num_epochs = 10
for epoch in range(num_epochs):
    running_loss = 0.0
    for images, labels in train_loader:
        optimizer.zero_grad()
        outputs = model(images)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()
        running_loss += loss.item()
    print(f"Epoch {epoch + 1}/{num_epochs}, Loss: {running_loss / len(train_loader)}")