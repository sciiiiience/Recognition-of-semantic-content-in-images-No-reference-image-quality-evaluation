from torch.utils.data import Dataset, DataLoader

import torch
from torch import nn
from torchvision.models import resnet18, ResNet18_Weights
from torchvision import transforms
from PIL import Image
import os
from torch.nn import CrossEntropyLoss, MSELoss
from torch.utils.data import random_split
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix
import numpy as np
import seaborn as sns
from block import *


class TID2008Dataset(Dataset):
    def __init__(self, image_dir, scores_file, distortion_scores_files):
        """
        image_dir: 图像文件夹的路径
        scores_file: 存储主观 IQA 得分的 txt 文件路径
        distortion_scores_files: 17个包含失真得分的 txt 文件列表
        """
        self.image_dir = image_dir
        self.image_filenames = []
        self.scores = []
        self.distortion_scores = [[] for _ in range(20)]
        self.num_classes = 25

        # 读取主观 IQA 分数
        with open(scores_file, 'r') as file:
            self.scores = [float(line.strip()) for line in file.readlines()]

        # 读取失真得分
        for i, file_path in enumerate(distortion_scores_files):
            with open(file_path, 'r') as file:
                self.distortion_scores[i] = [float(line.strip()) for line in file.readlines()]

        # 构建图像文件名列表
        for i in range(1, 26):  # 25 张参考照片
            for j in range(1, 18):  # 17 种失真方式
                for k in range(1, 5):  # 4 个失真程度
                    filename = f"I{i:02d}_{j:02d}_{k}.bmp"
                    self.image_filenames.append(filename)

    def __len__(self):
        return len(self.image_filenames)

    def __getitem__(self, idx):
        image_path = os.path.join(self.image_dir, self.image_filenames[idx])
        image = Image.open(image_path).convert('RGB')
        image = transforms.ToTensor()(image)
        # image = image.unsqueeze(0)

        score = torch.tensor(self.scores[idx] / 7.7143, dtype=torch.float32)  # 主观得分

        distortion_scores = torch.tensor([(self.distortion_scores[i][idx] -
                                           np.min(self.distortion_scores[i])) / (np.max(self.distortion_scores[i]) -
                                                                                 np.min(self.distortion_scores[i])) for
                                          i in range(17)], dtype=torch.float32)  # 归一化失真得分

        # 图片编号作为输出，用于回归分析
        # image_number = int(self.image_filenames[idx][1:3])
        image_number = int(self.image_filenames[idx][1:3]) - 1  # 从 0 开始索引
        one_hot_image_number = torch.zeros(self.num_classes, dtype=torch.float32)
        one_hot_image_number[image_number] = 1.0
        return image, distortion_scores, one_hot_image_number, score


# class IQANet(nn.Module):
#     def __init__(self):
#         super(IQANet, self).__init__()
#         # 语义信息提取
#         self.semantic_extractor = resnet18(pretrained='true')
#         original_model = resnet18(weights=ResNet18_Weights.IMAGENET1K_V1)
#         self.features = nn.Sequential(*list(original_model.children())[:-1])
#         self.fc = nn.Linear(512, 25)  # 特征数量
#         self.fc2 = nn.Linear(25, 1)  # iqa数量
#
#
#         # 粗略 IQA
#         self.rough_iqa_cnn = nn.Sequential(
#             nn.Conv2d(3, 16, kernel_size=3, padding=1),
#             nn.ReLU(),
#             nn.MaxPool2d(2),
#             nn.Conv2d(16, 32, kernel_size=3, padding=1),
#             nn.ReLU(),
#             nn.AdaptiveAvgPool2d((1, 1)),
#             nn.Flatten(),
#             nn.Linear(32, 1)
#         )
#         # 客观 IQA FNN
#         self.objective_iqa_fnn = nn.Sequential(
#             nn.Linear(17, 10),
#             nn.ReLU(),
#             nn.Linear(10, 1)
#         )
#         # 最终汇总
#         self.final_fc = nn.Sequential(
#             nn.Linear(3, 100),  # ResNet18 最后一个 fc 层输出为 1000，加上两个 IQA
#             nn.ReLU(),
#             nn.Linear(100, 100),  # ResNet18 最后一个 fc 层输出为 1000，加上两个 IQA
#             nn.ReLU(),
#             nn.Linear(100, 100),  # ResNet18 最后一个 fc 层输出为 1000，加上两个 IQA
#             nn.ReLU(),
#             nn.Linear(100, 100),  # ResNet18 最后一个 fc 层输出为 1000，加上两个 IQA
#             nn.ReLU(),
#             nn.Linear(100, 1)  # 输出预测 IQA 和参考图像编号
#         )
#
#     def forward(self, x, distortion_scores):
#         semantic_features = self.features(x)
#         semantic_features = semantic_features.view(x.size(0), -1)  # 展平特征
#         semantic_features = self.fc(semantic_features)  # 可选的新全连接层
#         semantic_iqa = self.fc2(semantic_features)  # 可选的新全连接层
#         # semantic_iqa= semantic_iqa.view(-1)
#
#         # semantic_features = self.semantic_extractor(x)
#         rough_iqa = self.rough_iqa_cnn(x)
#         # rough_iqa = rough_iqa.view(-1)
#         objective_iqa = self.objective_iqa_fnn(distortion_scores)
#         objective_iqa = objective_iqa.view(-1, 1)
#         combined_features = torch.cat([semantic_iqa, rough_iqa, objective_iqa], dim=1)
#         iqa = self.final_fc(combined_features)
#
#         return semantic_features, iqa


# # 设置设备
# device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
# model = IQANet().to(device)
# optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
# criterion = nn.MSELoss()  # MSE 可以根据需要更换为其他适合的损失函数
# num_epochs = 10000
#
# # 训练模型
# model.train()
# for epoch in range(num_epochs):
#     for images, distortion_scores, image_numbers, scores in data_loader:
#         images = images.to(device)
#         distortion_scores = distortion_scores.to(device)
#         scores = scores.to(device)  # 真实的 IQA 分数
#         image_numbers = image_numbers.to(device)  # 图像编号
#
#         optimizer.zero_grad()
#         outputs = model(images, distortion_scores)
#         loss_iqa = criterion(outputs[:, 0], scores)
#         loss_number = criterion(outputs[:, 1], image_numbers.float())
#         loss = loss_iqa + loss_number  # 损失加权可以根据需要调整
#         loss.backward()
#         optimizer.step()
#
#     print(f"Epoch {epoch+1}, Loss: {loss.item()}")


def train_model(data_loader, config_rough_iqa, config_objective_iqa, config_final_fc, config_name, lr, num_epochs=30):
    # 这里放置你的模型初始化、数据加载和训练循环
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = IQANet(rough_iqa_config=config_rough_iqa, objective_iqa_config=config_objective_iqa,
                   final_fc_config=config_final_fc).to(device)

    optimizer = torch.optim.Adam(model.parameters(), lr)  # 优化器
    criterion_number = CrossEntropyLoss()  # 分类损失，语义准则
    criterion_iqa = MSELoss(reduction='none')  # 回归损失，iqa准则
    # num_epochs = 30
    model.train()
    with open(config_name + "training_loss.txt", "w") as file:
        for epoch in range(num_epochs):
            total_loss = 0
            for images, distortion_scores, one_hot_image_number, scores in data_loader:
                images = images.to(device)
                distortion_scores = distortion_scores.to(device)
                one_hot_image_number = one_hot_image_number.to(device)
                scores = scores.to(device)

                optimizer.zero_grad()
                outputs = model(images, distortion_scores)
                loss_iqa = criterion_iqa(outputs[1].view(-1), scores)  # 原loss
                weights = loss_iqa / torch.sum(loss_iqa)  # loss占总loss的百分比，自适应的loss值
                weighted_loss_iqa = torch.sum(loss_iqa * weights)  # 权重再乘以loss得到最后的loss---iqa
                loss_number = criterion_number(outputs[0], one_hot_image_number.float())
                loss = weighted_loss_iqa + loss_number
                loss.backward()
                optimizer.step()

                total_loss += loss.item()
            average_loss = total_loss / len(data_loader)
            file.write(f"Epoch {epoch + 1}, Average Loss: {average_loss}\n")
            print(f"Epoch {epoch + 1}, Average Loss: {average_loss}")
    torch.save(model.state_dict(), config_name + 'model_state_dict.pth')
    print("Saved model state to 'model_state_dict.pth'")
    loss_values = []

    # 打开并读取文件
    with open(config_name + 'training_loss.txt', 'r') as file:
        for line in file:
            # 分割字符串并获取损失值
            parts = line.split(',')
            if len(parts) > 1:
                loss = float(parts[1].split(':')[1].strip())
                loss_values.append(loss)
    plt.figure(figsize=(10, 5))  # 设置图像大小
    plt.plot(loss_values, marker='o', linestyle='-', color='b')  # 绘制蓝色的线和点
    plt.title('Loss vs. Epochs')  # 图像标题
    plt.xlabel('Epoch')  # X轴标签，训练过程中的遍历数据集次数
    plt.ylabel('Loss')  # Y轴标签，真实值与预测值的差距
    plt.grid(True)  # 显示网格
    plt.savefig(config_name + 'trainprocess.png')
    return model
    #
    #
    # # 训练模型
    # model.train()
    # for epoch in range(num_epochs):
    #     for images, distortion_scores, image_numbers, scores in data_loader:
    #         images = images.to(device)
    #         distortion_scores = distortion_scores.to(device)
    #         scores = scores.to(device)
    #         image_numbers = image_numbers.to(device)
    #
    #         optimizer.zero_grad()
    #         outputs = model(images, distortion_scores)
    #         loss_iqa = criterion_iqa(outputs[1], scores)
    #         loss_number = criterion_number(outputs[0], image_numbers.float())
    #         loss = loss_iqa + loss_number
    #         loss.backward()
    #         optimizer.step()
    #
    #     print(f"Epoch {epoch+1}, Loss: {loss.item()}")


def evaluate_model(test_data_loader, config_name, model):  # 评估模型
    model.eval()
    all_preds = []
    all_labels = []
    all_scores = []
    all_predicted_scores = []
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    criterion_iqa = MSELoss()

    with torch.no_grad():
        for images, distortion_scores, one_hot_image_number, scores in test_data_loader:
            images = images.to(device)
            distortion_scores = distortion_scores.to(device)
            one_hot_image_number = one_hot_image_number.to(device)
            scores = scores.to(device)

            outputs = model(images, distortion_scores)
            predicted_scores = outputs[1]  # 假设最后一个是预测的 IQA 分数
            predicted_labels = outputs[0].argmax(1)  # 假设其他是 one-hot 类别预测

            all_preds.extend(predicted_labels.tolist())
            all_labels.extend(one_hot_image_number.argmax(1).tolist())
            all_scores.extend(scores.tolist())
            all_predicted_scores.extend(predicted_scores.tolist())

    # 绘制混淆矩阵
    cm = confusion_matrix(all_labels, all_preds)
    plt.figure(figsize=(10, 8))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues')
    plt.xlabel('Predicted Labels')
    plt.ylabel('True Labels')
    plt.title(config_name + 'Confusion Matrix')
    plt.savefig(config_name + 'confusion_matrix.png')

    # 绘制 IQA 预测散点图
    plt.figure(figsize=(10, 8))
    plt.scatter(all_scores, all_predicted_scores, alpha=0.5)
    mse_eva = criterion_iqa(torch.tensor(all_scores), torch.tensor(all_predicted_scores))
    plt.text(0.9, 0.9, f'MSE: {mse_eva:.2f}', fontsize=12,
             bbox=dict(facecolor='white', alpha=0.5))

    plt.xlabel('Actual IQA')
    plt.ylabel('Predicted IQA')
    # plt.xlim(0.4, 1)
    # plt.ylim(0, 1)
    plt.title(f'MSE: {mse_eva:.2f}_' + config_name + 'Scatter plot of IQA predictions')
    plt.grid(True)
    plt.savefig(config_name + 'iqa_predictions.png')

    return cm


if __name__ == '__main__':
    # 实例化数据集
    dataset = TID2008Dataset('distorted_images', 'mos.txt', ['ssim.txt', 'measure.txt', 'vifp.txt',
                                                             'MSSIM.txt', 'snr.txt', 'wsnr.txt', 'mse.txt', 'ifc.txt',
                                                             'nqm.txt', 'vif.txt',
                                                             'vsnr.txt', 'linlab.txt', 'xyz.txt', 'uqi.txt',
                                                             'psnrhvsm.txt',
                                                             'psnrhvs.txt', 'dctune.txt',
                                                             'dctune.txt', 'psnry.txt', 'psnr.txt'])
    total_size = len(dataset)
    train_size = int(0.7 * total_size)
    test_size = total_size - train_size
    for lr in [1e-3, 1e-4, 1e-5]:  # 学习率
        for lsf in [3, 5, 7]:  # final_fc 的层数
            for lso in [3, 5, 7]:  # object_iqa_fnn 的层数
                config_rough_iqa = {
                    'num_layers': 3,
                    'channels': [16, 32, 64]
                }

                config_objective_iqa = {
                    'input_features': 17,
                    'num_units': 100,
                    'num_layers': lso
                }

                config_final_fc = {
                    'input_features': 3,  # 根据前面层的输出调整
                    'num_units': 100,
                    'num_layers': lsf
                }
                config_name = "{}_{}_{}".format(lr, lsf, lso)
                train_dataset, test_dataset = random_split(dataset, [train_size, test_size])
                # 创建 DataLoader
                data_loader = DataLoader(train_dataset, batch_size=32, shuffle=True, num_workers=4)
                num_epochs = 50
                model = train_model(data_loader, config_rough_iqa, config_objective_iqa, config_final_fc, config_name,
                                    lr, num_epochs)
                test_dataset = DataLoader(test_dataset, batch_size=32, shuffle=True, num_workers=4)
                evaluate_model(test_dataset, config_name, model)
