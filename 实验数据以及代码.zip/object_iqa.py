import numpy as np
from skimage.metrics import peak_signal_noise_ratio as psnr
from skimage.metrics import structural_similarity as ssim
import cv2

# 假设img1和img2是两幅图像的像素矩阵，数据类型为float64
# 计算PSNR
img1 = cv2.imread('ref.png')
img2 = cv2.imread('img.png')

psnr_value = psnr(img1, img2, data_range=img2.max() - img2.min())

# 计算SSIM
ssim_value, _ = ssim(img1, img2, full=True)

mse_value = mean_squared_error(img1, img2)
